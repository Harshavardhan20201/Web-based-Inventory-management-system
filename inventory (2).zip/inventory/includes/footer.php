	</div>
	<!-- /container -->

	<!-- file input -->
	<script type="text/javascript" src="assets/plugins/fileinput/js/plugins/canvas-to-blob.min.js"></script>
	<script type="text/javascript" src="assets/plugins/fileinput/js/plugins/sortable.min.js"></script>
	<script type="text/javascript" src="assets/plugins/fileinput/js/plugins/purify.min.js"></script>
	<script type="text/javascript" src="assets/plugins/fileinput/js/fileinput.min.js"></script>
	<!-- datatables js -->
	<script type="text/javascript" src="assets/plugins/datatables/datatables.min.js"></script>


<div class="footer-copyright text-center">
        © 2018
        <a href="#"> HARSHA STORES. Designed by Harshavardhana M and Kousar.</a>
    </div>

</body>
</html>